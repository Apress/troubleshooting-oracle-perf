Modified ParsingTest2.c to do 200000 iterations.

Then the following script was started on the server:

time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
time ./ParsingTest2 ops\$cha/ops\$cha &
